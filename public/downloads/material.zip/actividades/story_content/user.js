function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6X1izZtRokV":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

